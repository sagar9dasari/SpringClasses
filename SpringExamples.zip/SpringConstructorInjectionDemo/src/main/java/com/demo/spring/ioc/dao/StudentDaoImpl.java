package com.demo.spring.ioc.dao;

import com.demo.spring.ioc.domain.Student;

public class StudentDaoImpl implements StudentDao {

public void insert(Student student) {
	System.out.println("Student Saved Successfully..");
	
}
}
