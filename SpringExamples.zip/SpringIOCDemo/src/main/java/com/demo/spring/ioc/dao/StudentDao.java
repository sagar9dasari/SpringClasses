package com.demo.spring.ioc.dao;

public interface StudentDao {

}
