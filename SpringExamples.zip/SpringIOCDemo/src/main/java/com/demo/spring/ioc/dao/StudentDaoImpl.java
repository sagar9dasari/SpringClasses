package com.demo.spring.ioc.dao;

public class StudentDaoImpl implements StudentDao {

}
