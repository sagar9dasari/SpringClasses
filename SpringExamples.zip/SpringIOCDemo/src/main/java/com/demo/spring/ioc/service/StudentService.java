package com.demo.spring.ioc.service;

public interface StudentService {

}
