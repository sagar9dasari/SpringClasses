package com.demo.spring.ioc.dao;

import com.demo.spring.ioc.domain.Student;

public interface StudentDao {
	public void insert(Student student);
}
