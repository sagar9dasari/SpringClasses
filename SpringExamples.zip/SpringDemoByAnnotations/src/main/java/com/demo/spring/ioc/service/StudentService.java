package com.demo.spring.ioc.service;

import com.demo.spring.ioc.domain.Student;

public interface StudentService {
	public void insert(Student student);
}
